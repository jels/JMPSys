package net.lion.apisystem.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.lion.apisystem.domain.Role;
import net.lion.apisystem.domain.User;
import net.lion.apisystem.exception.ApiException;
import net.lion.apisystem.repository.RoleRepository;
import net.lion.apisystem.repository.UserRepository;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;

import static java.util.Objects.requireNonNull;
import static net.lion.apisystem.enumeration.RoleType.ROLE_USER;
import static net.lion.apisystem.enumeration.VerificationType.ACCOUNT;
import static net.lion.apisystem.query.UserQuery.*;

@Repository
@RequiredArgsConstructor
@Slf4j
public class UserRepositoryImpl implements UserRepository <User> {

    private final NamedParameterJdbcTemplate jdbc;
    private final RoleRepository<Role> roleRepository;
    private final BCryptPasswordEncoder encoder;

    @Override
    public User create(User user) {
        //describir los pasos a seguir para realizar el insert de un nuevo usuario
        //Verificar la inexistencia del email
        if (getEmailCout(user.getEmail().trim().toLowerCase()) > 0 ) throw new ApiException("El correo ya se encuentra en uso. Inserte un correo diferete y pruebe de nuevo");
        //Guardar el nuevo usuario
        try{
            KeyHolder holder = new GeneratedKeyHolder();
            SqlParameterSource parameters = getSqlParameterSource(user);
            jdbc.update(INSERT_USER_QUERY, parameters, holder);
            user.setId_user(requireNonNull(holder.getKey()).longValue());
            // agregar el rol al usuario
            roleRepository.addRoleToUser(user.getId_user(), ROLE_USER.name());
            //URL de verificacion
            String verificationUrl = getVerificationUrl(UUID.randomUUID().toString(), ACCOUNT.getType());
            //Guardar la url de verificacion en su tabla
            jdbc.update(INSERT_ACCOUNT_VERIFICATION_URL_QUERY, Map.of("id_user", user.getId_user(), "url", verificationUrl));
            //Enviar el correo de verificacion con la url
            //emailService.sendVerificationUrl(user.getFirst_name(), user.getEmail(), verificationUrl, ACCOUNT);
            user.setEnabled(false);
            user.setNon_locked(true);
            //retornar el usuario creado nuevo
            return user;
        } catch (EmptyResultDataAccessException exception){
            throw new ApiException("No se encuentra el Rol: "+ ROLE_USER.name());
        } catch (Exception exception){
            throw new ApiException("A ocurrido un error. Por favor intentelo de nuevo");
        }
    }

    @Override
    public Collection<User> list(int page, int pageSize) {
        return null;
    }

    @Override
    public User get(Long id) {
        return null;
    }

    @Override
    public User update(User data) {
        return null;
    }

    @Override
    public Boolean delete(Long id) {
        return null;
    }

    private Integer getEmailCout(String email) {
        return jdbc.queryForObject(COUNT_USER_EMAIL_QUERY, Map.of("email", email), Integer.class);
    }

    private SqlParameterSource getSqlParameterSource(User user) {

        return new MapSqlParameterSource()
                .addValue("first_name", user.getFirst_name())
                .addValue("last_name", user.getLast_name())
                .addValue("email", user.getEmail())
                .addValue("password", encoder.encode(user.getPassword()));
    }

    private String getVerificationUrl(String key, String type){
        return ServletUriComponentsBuilder.fromCurrentContextPath().path("/user/verify/"+type+"/"+key).toUriString();
    }




}
