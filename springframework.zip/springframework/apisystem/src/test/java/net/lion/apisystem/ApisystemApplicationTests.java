package net.lion.apisystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApisystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
