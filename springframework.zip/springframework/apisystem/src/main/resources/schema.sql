/*
 * --- Reglas generales ---
 * Utilizar guion bajo user_name en lugar de la primera letra mayuscula UserName
 * Nombre de las tablas siempre en Plural
 * Usar nombre del campo id (user_id en lugar de id)
 * No usar nombre de columnas ambiguas
 * Nombrar las llaves foraneas de la misma manera que la llave primaria a la que se refiere
 * Nombrar todas las columnas en ingles para evitar los datos con caracteres especiales
 * Usar Mayusculas en todas las consultas SQL
 */

CREATE SCHEMA IF NOT EXISTS securecapita;

SET NAMES 'UTF8MB4';
SET TIME_ZONE = '-4:00';

USE securecapita;

DROP TABLE IF EXISTS Users;

CREATE TABLE Users
(
    id_user         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    first_name      VARCHAR(50) NOT NULL,
    last_name       VARCHAR(50) NOT NULL,
    email           VARCHAR(100) NOT NULL,
    password        VARCHAR(255) DEFAULT NULL,
    address         VARCHAR(255) DEFAULT NULL,
    phone           VARCHAR(30) DEFAULT NULL,
    title           VARCHAR(50) DEFAULT NULL,
    bio             VARCHAR(255) DEFAULT NULL,
    enabled         BOOLEAN DEFAULT FALSE,
    non_locked      BOOLEAN DEFAULT TRUE,
    using_mfa       BOOLEAN DEFAULT FALSE,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    image_url       VARCHAR(255) DEFAULT 'https://cdn-icons-png.flaticon.com/512/149/149071.png',
    CONSTRAINT UQ_Users_Email UNIQUE (email)
);

DROP TABLE IF EXISTS Roles;

CREATE TABLE Roles
(
    id_role         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(50) NOT NULL,
    permission      VARCHAR(255) NOT NULL,
    CONSTRAINT UQ_Roles_Name UNIQUE (name)
);

DROP TABLE IF EXISTS UserRoles;

CREATE TABLE UserRoles
(
    id_user_role    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_user         BIGINT UNSIGNED NOT NULL,
    id_role         BIGINT UNSIGNED NOT NULL,
    FOREIGN KEY (id_user) REFERENCES Users (id_user) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_role) REFERENCES Roles (id_role) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT UQ_UserRoles_User_Id UNIQUE (id_user)
);

DROP TABLE IF EXISTS Events;

CREATE TABLE Events
(
    id_event    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    type        VARCHAR(50) NOT NULL CHECK(type IN ('LOGIN_ATTEMPT','LOGIN_ATTEMPT_FAILURE','LOGIN_ATTEMPT_SUCCESS','PROFILE_UPDATE','PROFILE_PICTURE_UPDATE','ROLE_UPDATE','ACCOUNT_SETTINGS_UPDATE','PASSWORD_UPDATE','MFA_UPDATE')),
    description VARCHAR(255) NOT NULL,
    CONSTRAINT UQ_Events_Type UNIQUE (type)
);

DROP TABLE IF EXISTS UserEvents;

CREATE TABLE UserEvents
(
    id_user_event   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_user         BIGINT UNSIGNED NOT NULL,
    id_event        BIGINT UNSIGNED NOT NULL,
    device          VARCHAR(100) DEFAULT NULL,
    ip_address      VARCHAR(100) DEFAULT NULL,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_user) REFERENCES Users (id_user) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_event) REFERENCES Events (id_event) ON DELETE RESTRICT ON UPDATE CASCADE
);

DROP TABLE IF EXISTS AccountVerifications;

CREATE TABLE AccountVerifications
(
    id_acc_verification BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_user             BIGINT UNSIGNED NOT NULL,
    url                 VARCHAR(255) NOT NULL,
    FOREIGN KEY (id_user) REFERENCES Users (id_user) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT UQ_AccountVerifications_User_Id UNIQUE (id_user),
    CONSTRAINT UQ_AccountVerifications_Url UNIQUE (url)
);

DROP TABLE IF EXISTS ResetPasswordVerifications;

CREATE TABLE ResetPasswordVerifications
(
    id_reset_pass       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_user             BIGINT UNSIGNED NOT NULL,
    url                 VARCHAR(255) NOT NULL,
    expiration_date     DATETIME NOT NULL,
    FOREIGN KEY (id_user) REFERENCES Users (id_user) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT UQ_ResetPasswordVerifications_User_Id UNIQUE (id_user),
    CONSTRAINT UQ_ResetPasswordVerifications_Url UNIQUE (url)
);

DROP TABLE IF EXISTS TwoFactorVerifications;

CREATE TABLE TwoFactorVerifications
(
    id_tf_verification  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_user             BIGINT UNSIGNED NOT NULL,
    code                VARCHAR(10) NOT NULL,
    expiration_date     DATETIME NOT NULL,
    FOREIGN KEY (id_user) REFERENCES Users (id_user) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT UQ_TwoFactorVerifications_User_Id UNIQUE (id_user),
    CONSTRAINT UQ_TwoFactorVerifications_Code UNIQUE (code)
);




