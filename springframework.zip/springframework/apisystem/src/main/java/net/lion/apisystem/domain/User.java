package net.lion.apisystem.domain;


import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_DEFAULT;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(NON_DEFAULT)
public class User {

    private Long id_user;
    @NotEmpty(message = "Nombre no puede estar Vacio")
    private String first_name;
    @NotEmpty(message = "Apellido no puede estar Vacio")
    private String last_name;
    @NotEmpty(message = "Correo no puede estar Vacio")
    @Email(message = "Correo Invalido. Introduzca un correo valido")
    private String email;
    @NotEmpty(message = "Contrasenha no puede estar Vacio")
    private String password;
    private String address;
    private String phone;
    private String title;
    private String bio;
    private String image_url;
    private boolean enabled;
    private boolean non_locked;
    private boolean using_mfa;
    private LocalDateTime created_at;







}
