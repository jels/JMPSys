package net.lion.apisystem.enumeration;

public enum RoleType {

    ROLE_USER, ROLE_MANAGER, ROLE_ADMIN, ROLE_SYSADMIN


}
