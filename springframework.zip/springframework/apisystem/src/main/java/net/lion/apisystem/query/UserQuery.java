package net.lion.apisystem.query;

public class UserQuery {

    public static final String COUNT_USER_EMAIL_QUERY = "";
    public static final String INSERT_USER_QUERY = "";
    public static final String INSERT_ACCOUNT_VERIFICATION_URL_QUERY = "";


}
