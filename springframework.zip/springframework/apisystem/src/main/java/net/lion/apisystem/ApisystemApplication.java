package net.lion.apisystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApisystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApisystemApplication.class, args);
	}

}
