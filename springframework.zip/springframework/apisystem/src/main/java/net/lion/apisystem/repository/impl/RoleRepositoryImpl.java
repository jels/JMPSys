package net.lion.apisystem.repository.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.lion.apisystem.domain.Role;
import net.lion.apisystem.exception.ApiException;
import net.lion.apisystem.repository.RoleRepository;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Map;

import static net.lion.apisystem.enumeration.RoleType.ROLE_USER;

@Repository
@RequiredArgsConstructor
@Slf4j
public class RoleRepositoryImpl implements RoleRepository <Role> {

    private final NamedParameterJdbcTemplate jdbc;

    @Override
    public Role create(Role data) {
        return null;
    }

    @Override
    public Collection<Role> list(int page, int pageSize) {
        return null;
    }

    @Override
    public Role get(Long id) {
        return null;
    }

    @Override
    public Role update(Role data) {
        return null;
    }

    @Override
    public Boolean delete(Long id) {
        return null;
    }

    @Override
    public void addRoleToUser(Long userId, String roleName) {
        log.info("Agregando rol {} al usuario id: {}", roleName, userId);
        //describir los pasos a seguir para realizar el insert de un nuevo usuario
        try{
            Role role= jdbc.queryForObject(SELECT_ROLE_BY_NAME_QUERY, Map.of("roleName", roleName), new RoleRowMapper());
            jdbc.update(INSERT_ROLE_TO_USER, Map.of("id_user", userId, role.getId_role()));

        } catch (EmptyResultDataAccessException exception){
            throw new ApiException("No se encuentra el Rol: "+ ROLE_USER.name());
        } catch (Exception exception){
            throw new ApiException("A ocurrido un error. Por favor intentelo de nuevo");
        }

    }

    @Override
    public Role getRoleByUserId(Long userId) {
        return null;
    }

    @Override
    public Role getRoleByUserEmail(String email) {
        return null;
    }

    @Override
    public void updateUserRole(Long userId, String roleName) {

    }
}
